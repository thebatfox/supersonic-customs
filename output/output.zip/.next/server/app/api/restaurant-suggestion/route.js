(()=>{var e={};e.id=616,e.ids=[616],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},51455:e=>{"use strict";e.exports=require("node:fs/promises")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},73024:e=>{"use strict";e.exports=require("node:fs")},76760:e=>{"use strict";e.exports=require("node:path")},78335:()=>{},82820:(e,t,s)=>{"use strict";s.r(t),s.d(t,{patchFetch:()=>w,routeModule:()=>b,serverHooks:()=>v,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>S});var r={};s.r(r),s.d(r,{POST:()=>f});var o=s(96559),n=s(48088),i=s(37719),a=s(32190),u=s(51455),c=s(73024),g=s(76760),d=s.n(g);let p=d().join(process.cwd(),"data","restaurant-suggestions.json");async function l(){let e=d().join(process.cwd(),"data");(0,c.existsSync)(e)||await (0,u.mkdir)(e,{recursive:!0})}async function m(){try{if(await l(),(0,c.existsSync)(p)){let e=await (0,u.readFile)(p,"utf-8");return JSON.parse(e)}}catch(e){console.error("Error loading suggestions:",e)}return{}}async function h(e){try{await l(),await (0,u.writeFile)(p,JSON.stringify(e,null,2))}catch(e){console.error("Error saving suggestions:",e)}}async function x(e,t,s){let r=s?`🆕 New Restaurant Suggestion: ${e}`:`🔄 Restaurant Suggestion (${t}x): ${e}`,o=`
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .highlight { background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 15px 0; }
        .count-badge { background: ${s?"#10b981":"#f59e0b"}; color: white; padding: 5px 10px; border-radius: 15px; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>🎯 Restaurant Suggestion from SuperSonic Customs Website</h2>
      </div>

      <div class="content">
        <div class="highlight">
          <h3>📍 ${e}</h3>
          <p><span class="count-badge">${s?"NEW SUGGESTION":`SUGGESTED ${t} TIMES`}</span></p>
        </div>

        <p><strong>🕒 Date:</strong> ${new Date().toLocaleString("en-ZA",{timeZone:"Africa/Johannesburg",dateStyle:"full",timeStyle:"short"})}</p>

        <p><strong>📊 Status:</strong> ${s?"✨ First time suggestion":`🔥 Previously suggested ${t-1} time(s)`}</p>

        ${t>1?`
          <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0;">
            <strong>⚡ High Interest Alert!</strong><br>
            This venue has been suggested <strong>${t} times</strong>, indicating strong potential demand for acoustic services. Consider prioritizing outreach to this establishment.
          </div>
        `:""}

        ${t>=3?`
          <div style="background: #fee2e2; border-left: 4px solid #dc2626; padding: 15px; margin: 20px 0;">
            <strong>🚨 Priority Venue!</strong><br>
            With ${t} suggestions, this venue should be contacted immediately for acoustic consultation opportunities.
          </div>
        `:""}

        <hr style="margin: 30px 0; border: 1px solid #e5e7eb;">
        <p style="font-size: 12px; color: #6b7280;">
          💡 This suggestion was submitted through the floating suggestion form on your SuperSonic Customs website.<br>
          📧 Suggestion tracking system active - all duplicates are being counted automatically.
        </p>
      </div>
    </body>
    </html>
  `;console.log("\uD83D\uDCE7 EMAIL NOTIFICATION:",{to:process.env.NOTIFICATION_EMAIL||"info@supersoniccustoms.com",subject:r,html:o,metadata:{restaurant:e,count:t,isNew:s,timestamp:new Date().toISOString()}})}async function f(e){try{let{restaurantName:t}=await e.json();if(!t||!t.trim())return a.NextResponse.json({error:"Restaurant name is required"},{status:400});let s=t.trim(),r=new Date().toISOString(),o=await m(),n=s.toLowerCase(),i=!o[n];return o[n]?(o[n].count+=1,o[n].lastSuggested=r,o[n].timestamps.push(r)):o[n]={name:s,count:1,lastSuggested:r,timestamps:[r]},await h(o),await x(s,o[n].count,i),a.NextResponse.json({success:!0,message:"Suggestion recorded successfully",count:o[n].count,isNew:i})}catch(e){return console.error("Error processing suggestion:",e),a.NextResponse.json({error:"Failed to process suggestion"},{status:500})}}let b=new o.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/restaurant-suggestion/route",pathname:"/api/restaurant-suggestion",filename:"route",bundlePath:"app/api/restaurant-suggestion/route"},resolvedPagePath:"/home/project/supersonic-customs/src/app/api/restaurant-suggestion/route.ts",nextConfigOutput:"",userland:r}),{workAsyncStorage:y,workUnitAsyncStorage:S,serverHooks:v}=b;function w(){return(0,i.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:S})}},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[447,580],()=>s(82820));module.exports=r})();