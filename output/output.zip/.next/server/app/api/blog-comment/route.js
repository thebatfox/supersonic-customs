(()=>{var e={};e.id=114,e.ids=[114],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},51455:e=>{"use strict";e.exports=require("node:fs/promises")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},73024:e=>{"use strict";e.exports=require("node:fs")},76760:e=>{"use strict";e.exports=require("node:path")},78335:()=>{},79449:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>S,routeModule:()=>f,serverHooks:()=>w,workAsyncStorage:()=>v,workUnitAsyncStorage:()=>y});var s={};r.r(s),r.d(s,{POST:()=>b});var o=r(96559),n=r(48088),i=r(37719),a=r(32190),m=r(51455),c=r(73024),l=r(76760),d=r.n(l);let p=d().join(process.cwd(),"data","blog-comments.json");async function u(){let e=d().join(process.cwd(),"data");(0,c.existsSync)(e)||await (0,m.mkdir)(e,{recursive:!0})}async function g(){try{if(await u(),(0,c.existsSync)(p)){let e=await (0,m.readFile)(p,"utf-8");return JSON.parse(e)}}catch(e){console.error("Error loading comments:",e)}return{}}async function h(e){try{await u(),await (0,m.writeFile)(p,JSON.stringify(e,null,2))}catch(e){console.error("Error saving comments:",e)}}async function x(e){let t=`💬 New Blog Comment: ${e.postTitle}`,r=`
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .header { background: #2563eb; color: white; padding: 20px; text-align: center; }
        .content { padding: 20px; }
        .comment-box { background: #f8f9fa; border-left: 4px solid #2563eb; padding: 20px; margin: 20px 0; }
        .meta { color: #6b7280; font-size: 14px; margin-bottom: 15px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h2>💬 New Blog Comment Received</h2>
      </div>

      <div class="content">
        <h3>📝 Blog Post: ${e.postTitle}</h3>

        <div class="meta">
          <strong>👤 Commenter:</strong> ${e.name}<br>
          <strong>📧 Email:</strong> ${e.email}<br>
          <strong>🕒 Date:</strong> ${new Date(e.timestamp).toLocaleString("en-ZA",{timeZone:"Africa/Johannesburg",dateStyle:"full",timeStyle:"short"})}<br>
          <strong>🆔 Comment ID:</strong> ${e.id}
        </div>

        <div class="comment-box">
          <h4>💭 Comment:</h4>
          <p style="white-space: pre-wrap; margin: 0;">${e.comment}</p>
        </div>

        <div style="background: #e0f2fe; border-left: 4px solid #0288d1; padding: 15px; margin: 20px 0;">
          <strong>ℹ️ Comment Status:</strong> Pending approval<br>
          <small>This comment is automatically saved but not yet visible on the website. You can review and approve it through your admin system.</small>
        </div>

        <hr style="margin: 30px 0; border: 1px solid #e5e7eb;">
        <p style="font-size: 12px; color: #6b7280;">
          💡 This comment was submitted through the blog comments section on your SuperSonic Customs website.<br>
          📧 Comment tracking system active - all comments are being recorded for moderation.
        </p>
      </div>
    </body>
    </html>
  `;console.log("\uD83D\uDCE7 COMMENT EMAIL NOTIFICATION:",{to:process.env.NOTIFICATION_EMAIL||"info@supersoniccustoms.com",subject:t,html:r,metadata:{commentId:e.id,postSlug:e.postSlug,commenterEmail:e.email,timestamp:e.timestamp}})}async function b(e){try{let{postSlug:t,postTitle:r,name:s,email:o,comment:n}=await e.json();if(!t||!r||!s||!o||!n)return a.NextResponse.json({error:"All fields are required"},{status:400});if(!o.includes("@"))return a.NextResponse.json({error:"Please enter a valid email address"},{status:400});if(n.trim().length<10)return a.NextResponse.json({error:"Comment must be at least 10 characters long"},{status:400});let i={id:Date.now().toString()+Math.random().toString(36).substr(2,9),postSlug:t.trim(),postTitle:r.trim(),name:s.trim(),email:o.trim().toLowerCase(),comment:n.trim(),timestamp:new Date().toISOString(),approved:!1},m=await g();return m[t]||(m[t]=[]),m[t].push(i),await h(m),await x(i),a.NextResponse.json({success:!0,message:"Comment submitted successfully and is pending approval",commentId:i.id})}catch(e){return console.error("Error processing comment:",e),a.NextResponse.json({error:"Failed to submit comment"},{status:500})}}let f=new o.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/blog-comment/route",pathname:"/api/blog-comment",filename:"route",bundlePath:"app/api/blog-comment/route"},resolvedPagePath:"/home/project/supersonic-customs/src/app/api/blog-comment/route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:v,workUnitAsyncStorage:y,serverHooks:w}=f;function S(){return(0,i.patchFetch)({workAsyncStorage:v,workUnitAsyncStorage:y})}},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[447,580],()=>r(79449));module.exports=s})();